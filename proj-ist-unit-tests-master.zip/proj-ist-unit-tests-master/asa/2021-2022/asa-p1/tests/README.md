# Descrição dos Testes

Abaixo encontra-se a descrição de alguns dos testes. Alguns testes podem não ter descrição relevante.

## Problema 1

- `001`: Números repetidos
- `002`: Pode relevar problemas na contagem de sequências
- `003`
- `004`: Exemplo no enunciado

## Problema 2

- `001`
- `002`: Duas sequências de 10k números random cada uma
- `003`: Exemplo no enunciado (não é grande coisa, porque corresponde a uma LCS normal)
- `004`: Duas sequências de 1k números iguais cada uma
