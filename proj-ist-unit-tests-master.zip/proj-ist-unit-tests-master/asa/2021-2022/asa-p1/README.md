# ASA (Project 1) - Tests

This folder contains tests for the 1st project for ASA 2021/2022.

The run script is still in progress, feel free to run the tests manually if you'd like.
