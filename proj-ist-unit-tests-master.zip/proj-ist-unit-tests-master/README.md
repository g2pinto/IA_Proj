# Projetos IST Unit Tests

Este repo destina-se a centralizar todos os unit tests para os projetos de LEIC-A do IST, dos alunos que iniciaram o curso no ano letivo 2020/2021 (e alguns seguintes).

## Aviso

A maioria dos testes neste repo são criados por alunos e não são os testes oficiais.
Os testes aqui presentes podem não cobrir todos os casos testados pelos testes oficiais.
